#!/usr/bin/env python

from PIL import Image
from PIL.ExifTags import TAGS
from dateutil import parser
import datetime
import pytz

import boto3
import json
import psycopg2

BUCKET_NAME = 'borchert-photos'
THUMBNAIL_BUCKET_NAME = 'borchert-thumbnails'
THUMBNAIL_SIZE = 128, 128

def get_exif(im):
    ret = {}
    info = im._getexif()
    for tag, value in info.items():
        decoded = TAGS.get(tag, tag)
        ret[decoded] = value
    return ret

def handler(event, context):
    #print(json.dumps(event, indent=2))

    s3 = boto3.resource('s3')

    # Connect to the database
    dsn = "host={} dbname={} user={} password={}".format(
        "photos.cgbex3o9hubr.us-east-2.rds.amazonaws.com",
        "photos",
        "postgres",
        "q3Iyr1PRJNp9FkSG1se3"
    )

    conn = psycopg2.connect(dsn)

    for record in event['Records']:
        #Load object
        key = record["body"]
        filename = key.split("/")[-1]
        file_id = filename.split(".")[0]
        file_type = filename.split(".")[-1]

        #Only process JPEG images
        if file_type in ["jpg", "JPG", "jpeg", "JPEG"]:

            s3.Bucket(BUCKET_NAME).download_file(key, "/tmp/"+filename)

            #Generate and save thumbnail
            im = Image.open("/tmp/"+filename)
            exif_data = get_exif(im)
            print(exif_data)
            im.thumbnail(THUMBNAIL_SIZE)
            thumbnail_filename = file_id + ".thumbnail"
            im.save("/tmp/" + thumbnail_filename, "JPEG")
            thumbnail_key = BUCKET_NAME+"/"+key
            s3.Bucket(THUMBNAIL_BUCKET_NAME).upload_file("/tmp/"+thumbnail_filename, thumbnail_key)

            #Extract accessible EXIF data
            timestamp = datetime.datetime.strptime(exif_data["DateTimeOriginal"], "%Y:%m:%d %H:%M:%S")

            photo_id = file_id + " " + exif_data["DateTimeOriginal"]

            key = "https://{}.s3-ap-southeast-1.amazonaws.com/{}".format(BUCKET_NAME, key.replace(" ", "+"))
            thumbnail_key = "https://{}.s3-ap-southeast-1.amazonaws.com/{}".format(THUMBNAIL_BUCKET_NAME, thumbnail_key.replace(" ", "+"))

            print(photo_id)
            print(timestamp)
            print(key)
            print(thumbnail_key)

            #Write record to Postgres
            try:
                cur = conn.cursor()
                # Create a new record
                sql = """
                    INSERT INTO photos (photo_id, timestamp, key, thumbnail_key, name, rating) VALUES
                       (
                          '{}', '{}', '{}', '{}', '{}', {}
                       )
                    ON CONFLICT (photo_id)
                    DO
                          UPDATE
                         SET key = EXCLUDED.key, thumbnail_key = EXCLUDED.thumbnail_key, name = EXCLUDED.name, rating = EXCLUDED.rating;
                """
                cur.execute(sql.format(photo_id, timestamp, key, thumbnail_key, file_id, 0))
                conn.commit()
            except Exception as e:
                print(e)
            finally:
                cur.close()

    conn.close()

    return
